odoo.define('your_module.splash_screen', function (require) {
    "use strict";

    var core = require('web.core');
    var _t = core._t;

    $(document).ready(function () {
        // Show splash screen initially
        $('.splash-screen').show();

        // Hide splash screen when Odoo has fully loaded
        $(window).on('load', function () {
            $('.splash-screen').addClass('hidden');
            setTimeout(function () {
                $('.splash-screen').hide();
            }, 500); // Wait for the transition to complete
        });
    });
});
