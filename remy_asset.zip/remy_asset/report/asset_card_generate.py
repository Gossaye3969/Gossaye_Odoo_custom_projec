from odoo import api, fields, models, _


class AppointmentReportWizard(models.TransientModel):
    _name = "asset.move.card"
    _rec_name = 'product_template_id'
    _description = " Asset card"

    product_template_id = fields.Many2one('product.product', string='Asset NAme',
                                          domain="[('active', '=', True)]")
    stock_location = fields.Many2one('stock.location', "Location", company_dependent=True, check_company=True,
                                     default=lambda self: self.env['stock.location'].search([('usage', '=', 'fixed')],
                                                                                            limit=1),
                                     domain="[('usage', '=', 'fixed')]")
    product_moves = fields.One2many('stock.move.line', compute='_stock_moves')
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.company)

    @api.onchange('product_template_id', 'stock_location')
    def _stock_moves(self):
        domain = []
        if self.product_template_id:
            domain += ['&', ('state', '=', 'done'), ('product_id', '=', self.product_template_id.id)]
        if self.stock_location:
            domain += ['|', ('location_id', '=', self.stock_location.id),
                       ('location_dest_id', '=', self.stock_location.id)]
        self.product_moves = self.env['stock.move.line'].search(domain)

    def print_report(self):
        return self.env.ref('remy_asset.report_asset_card_report').report_action(self)
