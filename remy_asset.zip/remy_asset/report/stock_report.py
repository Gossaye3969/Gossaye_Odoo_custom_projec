from odoo import models, fields, api


class ProductStockReport(models.Model):
    _name = 'product.stock.reports'
    _description = 'Product Stock Report'
    _auto = False

    name = fields.Char(string='Product', readonly=True)
    quantity = fields.Float(string='Quantity On Hand', readonly=True)
    location = fields.Char(string='Location', readonly=True)

    @api.model
    def get_product_stock_data(self):
        query = """
            SELECT
                pt.name AS name,
                quant.quantity AS quantity,
                sl.complete_name AS location
            FROM
                stock_quant AS quant
            LEFT JOIN
                product_product AS pp ON quant.product_id = pp.id
            LEFT JOIN
                product_template AS pt ON pp.product_tmpl_id = pt.id
            LEFT JOIN
                stock_location AS sl ON quant.location_id = sl.id
        """
        self.env.cr.execute(query)
        return self.env.cr.dictfetchall()
