from odoo import api, fields, models


class ProductTemplate(models.Model):
    _inherit = "stock.quant"

    fixed = fields.Char('fixed')
    employee_id = fields.Many2one('hr.employee', string="Employee", help="The employee who holds the asset.")
    product_ids = fields.One2many(
        'stock.quant',
        'employee_id',
        # This should relate to the `hr.employee` model (you may need to define a custom relation in stock.quant)
        string="Assets in Custody",
    )

    @api.depends('stock_location')
    def _compute_assets(self):
        for record in self:
            # Fetch quant data based on the employee's stock_location
            quants = self.env['stock.quant'].search([('location_id', '=', record.stock_location.id)])
            # Populate the 'product_ids' based on the found quants
            record.product_ids = quants



