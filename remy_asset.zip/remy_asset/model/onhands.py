from odoo import models, fields, api


class Onhand(models.Model):
    _name = 'onhand'
    _description = 'Onhand Information'

    employee_id = fields.Many2one('hr.employee', string="Employee")
    location_id = fields.Many2one('stock.location', string="Location")
    company_id = fields.Many2one('res.company', string="Company", default=lambda self: self.env.company)
    line_ids = fields.One2many('onhand.lines', 'onhand_id', string="Onhand Lines")

    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        if self.employee_id and self.employee_id.stock_location:
            self.location_id = self.employee_id.stock_location
            # Clear existing lines if they exist
            self.line_ids = [(5, 0, 0)]
            # Fetch products in the selected location
            products = self.env['stock.quant'].search([
                ('location_id', '=', self.location_id.id),
                ('quantity', '>', 0)
            ])
            line_data = []
            # Add sequence numbers starting from 1
            seq = 1
            for product in products:
                line_data.append((0, 0, {
                    'seq_number': seq,
                    'product_id': product.product_id.id,
                    'uom_id': product.product_id.uom_id.id,
                    'onhand': product.quantity,
                }))
                seq += 1
            self.line_ids = line_data


class OnhandLines(models.Model):
    _name = 'onhand.lines'
    _description = 'Onhand Line Information'

    onhand_id = fields.Many2one('onhand', string="Onhand Reference", ondelete="cascade")
    seq_number = fields.Integer(string=" No")
    product_id = fields.Many2one('product.product', string="Product")
    uom_id = fields.Many2one('uom.uom', string="Unit of Measure")
    onhand = fields.Float(string="Onhand Quantity")
