from odoo import api, fields, models


class AssetManagementHistory(models.Model):
    _name = 'asset.management.history'
    _description = 'Asset Category'
    _order = "name asc"

    name = fields.Char('Category Name', required=True, store=True)
    paren_categ = fields.Many2one('asset.management.history', string='Parent Category')
    main_code = fields.Text(string='Parent Code')
    start_from = fields.Text(string='Start From')
    to = fields.Text(string='To')
    child_ids = fields.One2many('asset.management.history', 'paren_categ', string='Subcategories')

    @api.model
    def create(self, vals):
        """
        Automatically format name when creating a category.
        This sets the name based on the parent category if provided.
        """
        if vals.get('paren_categ') and vals.get('name'):
            parent_categ = self.browse(vals['paren_categ'])
            vals['name'] = f"{parent_categ.name} / {vals['name']}"  # Create hierarchical name
        return super(AssetManagementHistory, self).create(vals)

    def write(self, vals):
        """
        Update the 'name' field if 'paren_categ' or 'name' is changed.
        Propagate the change across the system wherever this name appears.
        """
        for record in self:
            if 'name' in vals:
                parent_categ_name = record.paren_categ.name if record.paren_categ else ''
                name = vals.get('name', record.name)

                # Create the new name based on the parent category
                new_name = f"{parent_categ_name} / {name}" if parent_categ_name else name

                # Only proceed if the new name is different from the current name
                if new_name != record.name:
                    vals['name'] = new_name

                    # Propagate the name change to other records where this name appears
                    self._update_related_records(record, new_name)

        return super(AssetManagementHistory, self).write(vals)

    def _update_related_records(self, record, new_name):
        """
        Update all records where this name appears, excluding the current record.
        """
        # Search for all records where this name appears in the system
        related_records = self.search([('name', '=', record.name)])

        # Exclude the record that triggered the update from the search result
        related_records = related_records - record

        # Update the name of all the related records
        for related_record in related_records:
            related_record.write({'name': new_name})
