from odoo import api, fields, models


class AssetManagementHistory(models.Model):
    _name = 'card.management'
    _description = 'card management'
    _auto = False

    uom_id = fields.Many2one('uom.uom', string='measure ', required=True)
    product_id = fields.Many2one('product.product', string='asset Item', required=True)
    location_id = fields.Many2one('stock.location', string='Location', tracking=True, required=True)
    quantity = fields.Float(string='On Hand ', tracking=True)

    @property
    def _table_query(self):
        return f"""
              pp.id AS product_id,
                pp.uom_id AS uom_id,
                sq.quantity AS quantity,
                sq.location_id AS location_id
            FROM 
                product_product pp
            LEFT JOIN 
                stock_quant sq ON pp.id = sq.product_id
        """
