from odoo import api, fields, models, _, exceptions
from odoo.exceptions import UserError
from odoo.exceptions import ValidationError


class AssetTransfer(models.Model):
    _name = 'internal.transfer'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'reference'
    _description = 'asset management return History'

    reference = fields.Char(string='Transfer Reference', required=True, copy=False, readonly=True,
                            default=lambda self: _('New'))
    return_date = fields.Datetime(string='Transfer Date', tracking=True, default=lambda self: fields.Date.today())
    returned_by = fields.Many2one('hr.employee', string="Transfer From", tracking=True, required=True)
    returned_to = fields.Many2one('hr.employee', string="Transfer To", tracking=True, required=True)

    returned_id = fields.Many2one('res.partner', string="Returned by", tracking=True)
    location = fields.Many2one('stock.location', string='Source Location', tracking=True, required=True)
    location_dest_id = fields.Many2one('stock.location', string='Dest Location', tracking=True, required=True)
    company_id = fields.Many2one('res.company', string="Company", tracking=True, required=True,
                                 default=lambda self: self.env.company)
    requesting_department = fields.Many2one('hr.department', string="Department", tracking=True, required=True)
    requesting_departments = fields.Many2one('hr.department', string="Department", tracking=True, required=True)

    picking_type_id = fields.Many2one('stock.picking.type', string='Operations', required=True, tracking=True)
    Purpose = fields.Text('Purpose')
    return_count = fields.Integer("Return", compute='_compute_return_count')
    confirm_date = fields.Datetime("confirmation_date")
    prescription_line_id = fields.One2many('internal.transfer.lines', 'asset_ids',
                                           string="prescription lines")
    state = fields.Selection(
        [('new', 'Draft'), ('transfered', 'Validated'), ('cancel', 'Cancelled')],
        default='new',
        string="Status", tracking=True)

    @api.constrains('returned_by', 'returned_to')
    def _check_transfer_employees(self):
        for record in self:
            if record.returned_by == record.returned_to:
                raise UserError("The 'Transfer From' and 'Transfer To' fields cannot be the same employee.")

    @api.model
    def create(self, vals):
        if vals.get('returned_by') == vals.get('returned_to'):
            raise UserError("The 'Transfer From' and 'Transfer To' fields cannot be the same employee.")
        return super(AssetTransfer, self).create(vals)

    def write(self, vals):
        for record in self:
            returned_by = vals.get('returned_by', record.returned_by.id)
            returned_to = vals.get('returned_to', record.returned_to.id)
            if returned_by == returned_to:
                raise UserError("The 'Transfer From' and 'Transfer To' fields cannot be the same employee.")
        return super(AssetTransfer, self).write(vals)

    @api.onchange('returned_to')
    def onchange_returned_to(self):
        if self.returned_to:
            if self.returned_to.stock_location:
                self.location_dest_id = self.returned_to.stock_location
            else:
                self.location_dest_id = ''

            if self.returned_to.department_id:
                self.requesting_departments = self.returned_to.department_id
            else:
                self.requesting_departments = False
        else:
            self.location_dest_id = ''
            self.requesting_departments = False

    @api.model
    def default_get(self, fields):
        defaults = super(AssetTransfer, self).default_get(fields)
        config_settings = self.env['res.config.settings'].sudo().get_values()
        defaults['picking_type_id'] = config_settings.get('picking_types_ids')
        return defaults

    @api.constrains('prescription_line_id')
    def _check_prescription_lines(self):
        for record in self:
            if not record.prescription_line_id:
                raise UserError(_('There are no records in Prescription Lines.Add Lists of Assets With Quantity.'))

    @api.constrains('state')
    def _check_state_change(self):
        group_user = self.env.ref('base.group_user')
        group_manager = self.env.ref('remy_asset.group_asset_management_manager')
        for record in self:
            if record.state == 'transfered' and self.env.uid in group_user.users.ids and record.create_uid.id == self.env.uid:
                if self.env.uid not in group_manager.users.ids:
                    raise UserError(
                        _("Only Fixed Asset  Manager can Validate a fixed  Asset  Return  Requests."))

    @api.constrains('location', 'location_dest_id')
    def _check_same_location(self):
        for record in self:
            if record.location and record.location_dest_id and record.location == record.location_dest_id:
                raise UserError("Source Location and Destination Location cannot be the same.")

    @api.onchange('returned_by')
    def onchange_returned_by(self):
        if self.returned_by:
            if self.returned_by.stock_location:
                self.location = self.returned_by.stock_location
        else:
            self.location = ''

        if self.returned_by:
            if self.returned_by.department_id:
                self.requesting_department = self.returned_by.department_id
        else:
            self.requesting_department = ''

    def unlink(self):
        # Check if any record is in the "Done" state
        for record in self:
            if record.state == 'transfered':
                raise exceptions.UserError("You can't delete a record in Transfered state.")
        return super(AssetTransfer, self).unlink()

    @api.model
    def search(self, args, offset=0, limit=None, order=None):
        company_id = self.env.company  # Get the currently selected company

        # Add a new domain condition to filter by company_id
        new_args = args + [('company_id', '=', company_id.id)]

        return super(AssetTransfer, self).search(new_args, offset, limit, order)

    def _compute_return_count(self):
        return_counts = self.env['stock.picking'].search_count(
            [('origin', '=', self.reference)])
        self.return_count = return_counts

    def action_open_return(self):
        move_line_obj = self.env['stock.picking']
        created_move_lines = []
        stock_move_obj = self.env['stock.move']

        for adjustment in self:
            existing_picking = move_line_obj.search([('origin', '=', adjustment.reference)], limit=1)

        if existing_picking:
            # View the existing stock picking record
            action = {
                'name': 'Stock Move Lines',
                'type': 'ir.actions.act_window',
                'res_model': 'stock.picking',
                'view_mode': 'form',
                'res_id': existing_picking.id,  # View the specific existing record
                'readonly': 'True',
            }
            return action

        else:
            # Create stock move line
            move_line = move_line_obj.create({
                'partner_id': adjustment.returned_id.id,
                'picking_type_id': adjustment.picking_type_id.id,
                'location_id': adjustment.location.id,
                'location_dest_id': adjustment.location_dest_id.id,
                'scheduled_date': adjustment.return_date,
                'origin': adjustment.reference,
                # Add other fields as needed
            })

            created_move_lines.append(move_line.id)
            # Create stock moves
            for line in adjustment.prescription_line_id:
                move_vals = {
                    'product_id': line.returned_item.id,
                    'name': line.returned_item.display_name,
                    'date': adjustment.return_date,
                    'name': line.returned_item.display_name,
                    'picking_id': move_line.id,
                    'product_uom': line.uom_id.id,
                    'description_picking': line.description,
                    'product_uom_qty': line.qty,
                    'company_id': adjustment.company_id.id,
                    'location_id': adjustment.location.id,
                    'location_dest_id': adjustment.location_dest_id.id,
                    # Add other fields as needed
                }
                new_move = self.env['stock.move'].create(move_vals)
                stock_move_obj += new_move
        if created_move_lines:
            # Create action to open stock.move.line records
            action = {
                'name': 'Stock Move Lines',
                'type': 'ir.actions.act_window',
                'res_model': 'stock.picking',
                'view_mode': 'tree,form',
                'readonly': 'True',
                'domain': [('id', 'in', created_move_lines)]
            }

            return action
        else:
            raise UserError("No stock move line records were created.")

    @api.model
    def create(self, vals):
        if vals.get('reference', _('New')) == _('New'):
            vals['reference'] = self.env['ir.sequence'].next_by_code('internal.transfer') or _('New')
            res = super(AssetTransfer, self).create(vals)
        return res

    def write(self, vals):
        if 'state' in vals and vals['state'] == 'new' and self.state == 'transfered':
            raise UserError(_('Cannot set a Returned record back to New.'))
        return super(AssetTransfer, self).write(vals)

    def action_new(self):
        self.state = 'new'

    def action_returned(self):
        self.state = 'transfered'

    def action_cancel(self):
        self.state = 'cancel'

    @api.onchange('Returned_Item')
    def onchange_Returned_Item(self):
        if self.Returned_Item:
            if self.Returned_Item.measure:
                self.measure = self.Returned_Item.measure

            else:
                self.measure = ''

    class HospitalAppointment(models.Model):
        _name = "internal.transfer.lines"
        _description = "asset prescription line"

        returned_item = fields.Many2one('product.product', string='Transfered Item',
                                        required=True)
        description = fields.Text(string='Description')
        measure = fields.Many2one('uom.uom', string='Unit of Measure', tracking=True)
        uom_id = fields.Many2one('uom.uom', string='Unit of Measure', tracking=True, required=True)
        qty = fields.Integer(string="Quantity", required=True)
        asset_ids = fields.Many2one('internal.transfer', string="Asset")
        readonly = fields.Boolean(string='Read-Only', compute='_compute_readonly', store=True)

        @api.depends('asset_ids.state')
        def _compute_readonly(self):
            for record in self:
                record.readonly = record.asset_ids.state == 'transfered'

        @api.onchange('returned_item')
        def onchange_requested_item(self):
            """
            Automatically select the Unit of Measure and description based on the requested item.
            """
            if self.returned_item:
                # Set UoM to the default UoM of the requested item
                self.uom_id = self.returned_item.uom_id.id
                # Set description to the description of the requested item
                self.description = self.returned_item.description or ''

        @api.constrains('qty')
        def _check_qty(self):
            for record in self:
                if record.qty <= 0:
                    raise ValidationError(_('Quantity must be greater than or equals to One(1).'))
