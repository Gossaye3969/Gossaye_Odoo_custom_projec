from odoo import api, fields, models, tools, _, exceptions
from odoo.exceptions import UserError, AccessError
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)


class AssetRequestManagementHistory(models.Model):
    _name = 'asset.management.request.history'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'request'
    _check_company_auto = True
    _rec_name = 'reference'

    reference = fields.Char(string='Request Reference', required=True, copy=False, sortable="True", readonly=True,
                            default=lambda self: _('New'))
    Request_Date = fields.Date(string='Request Date', tracking=True, sortable="True",
                               default=lambda self: fields.Date.today())
    requested_by = fields.Many2one('hr.employee', string="Requested By", tracking=True, required=True)
    requested_id = fields.Many2one('res.partner', string="Requested by", tracking=True)
    requesting_department = fields.Many2one('hr.department', string="Department", tracking=True, required=True)
    location = fields.Many2one('stock.location', string='Source Location', tracking=True, required=True,
                               default=lambda self: self._get_default_location())
    location_dest_id = fields.Many2one('stock.location', string='Dest Location', tracking=True, required=True, )
    pickings_ids = fields.One2many('stock.picking', 'request_id', string='requests')
    picking_type_id = fields.Many2one('stock.picking.type', string='Operation Type', tracking=True, required=True,
                                      default=lambda self: self._get_default_picking_type())
    prescription_line_ids = fields.One2many('fixed.asset.management.history.lines', 'asset_id',
                                            string="prescription lines")
    move_ids = fields.One2many('stock.move', 'request_history_id', string='Stock Moves', store=True, readonly=1)
    company_id = fields.Many2one('res.company', string="Company", tracking=True, required=True,
                                 default=lambda self: self.env.company)
    issued_count = fields.Integer("meeting", compute='_compute_issued_count')
    Purpose = fields.Text('Purpose')
    state = fields.Selection(
        [('new', 'Draft'), ('confirm', 'Requested'), ('request', 'Confirmed'), ('approved', 'Approved'),
         ('cancel', 'cancelled')],
        default='new',
        string="Status", tracking=True, track_visibility='onchange')
    sequence_id = fields.Many2one('ir.sequence', string='Sequence')
    contact = fields.Many2one('res.partner', string="Contact", tracking=True)

    @api.model
    def _get_default_picking_type(self):
        # Retrieve the default picking type for the current company
        company_id = self.env.company.id
        default_picking_type = self.env['ir.default'].sudo()._get(
            'res.config.settings', 'picking_type_id', company_id=company_id)
        return default_picking_type

    @api.model
    def _get_default_location(self):
        company_id = self.env.company.id
        picking_type = self.env['ir.default'].sudo()._get('res.config.settings', 'picking_type_id',
                                                          company_id=company_id)
        if picking_type:
            picking_type_record = self.env['stock.picking.type'].browse(picking_type)
            return picking_type_record.default_location_src_id.id
        return False

    @api.constrains('prescription_line_ids')
    def _check_prescription_line_ids(self):
        for record in self:
            if not record.prescription_line_ids:
                raise UserError(_('There are no records in Prescription Lines.Add Lists of Assets With Quantity.'))

    @api.constrains('state')
    def _check_state_change(self):
        group_manager = self.env.ref('remy_asset.group_asset_management_manager')
        group_admin = self.env.ref('remy_asset.group_asset_management_admin')

        for record in self:
            # Check if the user belongs to the Manager or Admin group
            is_manager_or_admin = self.env.user.has_group('remy_asset.group_asset_management_manager') or \
                                  self.env.user.has_group('remy_asset.group_asset_management_admin')

            # Prevent state change to 'approved' unless the user is a manager or admin
            if record.state == 'approved':
                if not is_manager_or_admin:
                    raise UserError(_("Only Fixed Asset Manager or Administrator can approve a fixed Asset Request."))

            # Prevent state change to 'cancel' unless the user is a manager or admin
            if record.state == 'cancel':
                if not is_manager_or_admin:
                    raise UserError(_("You have no permission to cancel a fixed Asset Request."))

    @api.constrains('location', 'location_dest_id')
    def _check_same_location(self):
        for record in self:
            if record.location and record.location_dest_id and record.location == record.location_dest_id:
                raise UserError("Source Location and Destination Location cannot be the same.")

    def unlink(self):
        for record in self:
            if record.state == 'approved':
                raise UserError(_("You cannot delete a record that is in 'Done' state."))
        return super(AssetRequestManagementHistory, self).unlink()

    def write(self, vals):
        if 'state' in vals:
            for record in self:
                # Prevent transition from 'approved' back to 'confirm' or 'request'
                if record.state == 'approved' and vals['state'] in ['confirm', 'request', 'cancel']:
                    raise UserError(
                        _("You cannot change the state from 'Approved' back to 'Requested'  'Confirmed' or 'cancelled'."))
        return super(AssetRequestManagementHistory, self).write(vals)

    @api.onchange('requested_by')
    def onchange_requested_by(self):
        if self.requested_by:
            if self.requested_by.stock_location:
                self.location_dest_id = self.requested_by.stock_location
        else:
            self.location_dest_id = ''

        if self.requested_by:
            if self.requested_by.department_id:
                self.requesting_department = self.requested_by.department_id
        else:
            self.requesting_department = ''

    @api.model
    def search(self, args, offset=0, limit=None, order=None):
        # Get all selected companies
        selected_companies = self.env.companies

        # Create a domain to filter by selected companies
        domain = [('company_id', 'in', selected_companies.ids)]

        # Combine the new domain with the existing args
        new_args = args + domain

        return super(AssetRequestManagementHistory, self).search(new_args, offset, limit, order)

    def _compute_issued_count(self):
        issued_counts = self.env['stock.picking'].search_count(
            [('origin', '=', self.reference)])
        self.issued_count = issued_counts

    @api.model
    def create(self, vals):
        if vals.get('reference', _('New')) == _('New'):
            vals['reference'] = self.env['ir.sequence'].next_by_code('asset.management.request.history') or _('New')
            res = super(AssetRequestManagementHistory, self).create(vals)
        return res

    def action_new(self):
        self.state = 'new'

    def action_confirm(self):
        self.state = 'confirm'

    def action_request(self):
        """
        This method allows users to set the state to 'request' only if they belong to one of the following groups:
        - Asset Management User (group_asset_management_user)
        - Manager (group_asset_management_manager)
        - Administrator (group_asset_management_admin)

        The state is only changed if the current state is 'new' (Draft).
        """
        # Check if the user belongs to one of the allowed groups: Validator, Manager, or Administrator
        if not (self.env.user.has_group('remy_asset.group_asset_management_user') or
                self.env.user.has_group('remy_asset.group_asset_management_manager') or
                self.env.user.has_group('remy_asset.group_asset_management_admin')):
            raise UserError(
                _("You do not have permission to confirm this request as you do not belong to the required group."))

        # Check if the current state is 'new' (Draft)
        for record in self:
            if record.state == 'confirm':  # Ensure the request is in the 'new' state before confirming
                record.state = 'request'
            else:
                raise UserError(_("Only requests in 'Draft' state can be confirmed."))

    def action_approved(self):
        self.action_open_request()
        self.state = 'approved'

    def action_cancel(self):
        self.state = 'cancel'

    def action_open_request(self):
        move_line_obj = self.env['stock.picking']
        created_move_lines = []
        stock_move_obj = self.env['stock.move']

        for adjustment in self:
            # Check for existing stock picking by reference
            existing_picking = move_line_obj.search([('origin', '=', adjustment.reference)], limit=1)

            if existing_picking:
                # View the existing stock picking record
                action = {
                    'name': 'Stock Move Lines',
                    'type': 'ir.actions.act_window',
                    'res_model': 'stock.picking',
                    'view_mode': 'form',
                    'res_id': existing_picking.id,  # View the specific existing record
                    'readonly': True,
                }
                return action
            else:
                # Create a new stock picking record
                location = self.env['stock.location'].search([('name', '=', adjustment.location.name)], limit=1)
                employee_id = location.responsible.id if location else False

                move_line = move_line_obj.create({
                    'request_id': adjustment.pickings_ids.id,
                    'partner_id': adjustment.requested_id.id,
                    'picking_type_id': adjustment.picking_type_id.id,
                    'location_id': adjustment.location.id,
                    'location_dest_id': adjustment.location_dest_id.id,
                    'date_done': adjustment.Request_Date,
                    'origin': adjustment.reference,
                    'employee_id': employee_id,  # Set employee from location's responsible
                    'resp_id': adjustment.requested_by.id,
                    'department_id': adjustment.requesting_department.id,
                    # Add other fields as needed
                })

                created_move_lines.append(move_line.id)

                # Create stock moves associated with the picking
                for line in adjustment.prescription_line_ids:
                    move_vals = {
                        'request_history_id': adjustment.id,
                        'product_id': line.requested_item.id,
                        'name': line.requested_item.display_name,
                        'date': adjustment.Request_Date,
                        'picking_id': move_line.id,
                        'product_uom': line.uom_id.id,
                        'product_uom_qty': line.qty,
                        'description_picking': line.description,
                        'company_id': adjustment.company_id.id,
                        'location_id': adjustment.location.id,
                        'location_dest_id': adjustment.location_dest_id.id,
                        # Add other fields as needed
                    }
                    new_move = self.env['stock.move'].create(move_vals)
                    stock_move_obj |= new_move

        if created_move_lines:
            # Open the created or existing stock picking records in a new window
            action = {
                'name': 'Stock Move Lines',
                'type': 'ir.actions.act_window',
                'res_model': 'stock.picking',
                'view_mode': 'tree,form',
                'readonly': True,
                'domain': [('id', 'in', created_move_lines)]
            }
            return action
        else:
            raise UserError("No stock move line records were created.")

    class FixedAssetManagementHistoryLines(models.Model):
        _name = "fixed.asset.management.history.lines"
        _description = "asset prescription lines"
        requested_item = fields.Many2one('product.product', string='Item', tracking=True, required=True)
        uom_id = fields.Many2one('uom.uom', string='Unit of Measure', tracking=True, store=True)
        description = fields.Text(string='Description')
        qty = fields.Integer(string="Quantity", required=True, tracking=True, store=True, readonly=True, default=1)
        meeting_count = fields.Integer(string="meeting", invisible=True)
        asset_id = fields.Many2one('asset.management.request.history', string="Asset", ondelete='cascade')
        move_line_id = fields.Many2one('asset.move.line', string='Related Move Line')
        move_line_ids = fields.Many2one('stock.move.line', string='stock Move Line')
        move_lines_ids = fields.Many2one('stock.move', string='stock Move ')

        @api.constrains('asset_id')
        def _check_asset_id(self):
            for record in self:
                if not record.asset_id:
                    raise UserError(_("Asset  must be set!"))

        @api.onchange('requested_item')
        def onchange_requested_item(self):
            """
            Automatically select the Unit of Measure and description based on the requested item.
            """
            if self.requested_item:
                # Set UoM to the default UoM of the requested item
                self.uom_id = self.requested_item.uom_id.id
                # Set description to the description of the requested item
                self.description = self.requested_item.description or ''

        @api.onchange('requested_item')
        def onchange_requested_item(self):
            if self.requested_item:
                if self.requested_item.uom_id:
                    self.uom_id = self.requested_item.uom_id
            else:
                self.uom_id = ''

            if self.requested_item:
                if self.requested_item.description:
                    self.description = self.requested_item.description
            else:
                self.description = ''

        @api.constrains('qty')
        def _check_qty(self):
            for record in self:
                if record.qty <= 0:
                    raise ValidationError(_('Quantity must be greater than zero.'))

    class FixedAssetLines(models.Model):
        _name = "fixed.asset.lines"

        name = fields.Char(string='Name')
        description = fields.Text(string='Description')
        user_id = fields.Many2one('res.users', string='User', readonly=True)
        line_id = fields.Many2one('asset.management.request.history', string="line ID", ondelete='cascade')

    @api.model
    def get_current_user(self):
        """
        This method retrieves the currently logged-in user.
        """
        return self.env.user
