from odoo import api, fields, models, _
from odoo.exceptions import AccessError
from odoo.exceptions import ValidationError


class ProductTemplate(models.Model):
    _inherit = "product.template"

    type = fields.Selection(default=lambda self: 'product')
    location_id = fields.Many2one('stock.location', string='Location', tracking=True, store=True)
    fixed_asset = fields.Boolean(string="Fixed Asset", default=False, tracking=True)
    category = fields.Many2one('asset.management.history', string='Asset Category', tracking=True)
    new_reference = fields.Char(string='Asset Tag', tracking=True, store=True)
    serial_number = fields.Char('Serial Number', tracking=True)
    vendor = fields.Many2one('res.partner', string='Vendor', tracking=True, compute='_compute_vendor', store=True)
    old_code = fields.Char(string='Old Code', tracking=True)

    def product_template_print_tag(self):
        return self.env.ref('remy_asset.product_template_print_tag').report_action(self)

    @api.depends('company_id.short_name', 'responsible.department_id', 'location_id')
    def generate_asset_tag(self):
        for record in self:
            if record.company_id and record.id:
                # Fetch the location's responsible employee
                responsible_employee = record.location_id.responsible

                # Check if responsible employee exists
                if responsible_employee:
                    # Fetch the department name from the responsible employee
                    department = responsible_employee.department_id

                    if department:
                        department_name = department.short_name
                    else:
                        # Raise a validation error if the department is not found
                        raise ValidationError(_("The responsible employee does not have a department assigned."))

                else:
                    # Raise a validation error if no responsible employee is found
                    raise ValidationError(_("No responsible employee found for the location."))

                # Construct the Asset Tag using the company short name, department short name, and asset id
                record.new_reference = f"GM/{record.company_id.short_name}/{department_name}/{record.id}/17"
            else:
                record.new_reference = ''

    @api.depends('product_variant_ids')
    def _compute_vendor(self):
        for product in self:
            # Retrieve the first purchase order line related to the product
            purchase_order_line = self.env['purchase.order.line'].search(
                [('product_id', 'in', product.product_variant_ids.ids)],
                limit=1
            )
            # Set the vendor from the associated purchase order line's partner_id
            product.vendor = purchase_order_line.order_id.partner_id if purchase_order_line else False

    @api.model
    def create(self, vals):
        # Create the product template record
        record = super(ProductTemplate, self).create(vals)

        # If the fixed_asset flag is True, create or update a record in fixed.asset.management.history
        if vals.get('fixed_asset', False):
            asset_history_model = self.env['fixed.asset.management.history']
            # Check if an asset record already exists for this product
            existing_asset = asset_history_model.search([('asset_name', '=', record.product_variant_id.id)], limit=1)

            asset_vals = {
                'asset_name': record.product_variant_id.id,  # Linking to the product variant
                'category': record.category.id,
                'image': record.image_1920,
                'fixed_ok': True,
                'other_ok': False,
                'description': record.description,
                'measure': record.uom_id.id if record.uom_id else False,
                'initial_cost': record.standard_price,
                'default_code': record.default_code,
                'new_reference': record.new_reference,
                'serial_number': record.serial_number,
                'company_id': record.company_id.id,
                'category_id': record.categ_id.id,
            }

            if existing_asset:
                # Update the existing asset record
                existing_asset.write(asset_vals)
            else:
                # Create a new asset record
                asset_history_model.create(asset_vals)

        return record

    def write(self, vals):
        # Check if the `fixed_asset` field is being set to False
        if 'fixed_asset' in vals and vals['fixed_asset'] is False:
            # Only allow users in the specified groups to set `fixed_asset` to False
            if not self.env.user.has_group('remy_asset.group_asset_management_manager') and \
                    not self.env.user.has_group('remy_asset.group_asset_management_admin'):
                raise AccessError("You do not have the necessary permissions to set Fixed Asset to False.")

        # First, call the super method to apply any changes
        res = super(ProductTemplate, self).write(vals)

        for record in self:
            # If the `fixed_asset` field is being updated
            if 'fixed_asset' in vals:
                if vals['fixed_asset']:  # If fixed_asset is being set to True
                    record._create_or_update_asset()
                else:  # If fixed_asset is being set to False
                    record._update_asset_fixed_ok_to_false()

            # If other relevant fields are updated, ensure asset update if `fixed_asset` is True
            elif any(field in vals for field in ['category', 'new_reference', 'serial_number', 'description',
                                                 'image_1920', 'standard_price', 'uom_id', 'categ_id', 'default_code']):
                if record.fixed_asset:
                    record._create_or_update_asset()

        return res

    def _create_or_update_asset(self):
        for record in self:
            asset_history_model = self.env['fixed.asset.management.history']
            # Search for an existing asset record
            existing_asset = asset_history_model.search([('asset_name', '=', record.product_variant_id.id)], limit=1)

            asset_vals = {
                'asset_name': record.product_variant_id.id,
                'category': record.category.id,
                'fixed_ok': True,
                'other_ok': False,
                'description': record.description,
                'measure': record.uom_id.id if record.uom_id else False,
                'initial_cost': record.standard_price,
                'image': record.image_1920,
                'default_code': record.default_code,
                'new_reference': record.new_reference,
                'serial_number': record.serial_number,
                'company_id': record.company_id.id,
                'category_id': record.categ_id.id,
            }

            if existing_asset:
                # Update the existing asset record
                existing_asset.write(asset_vals)
            else:
                # Create a new asset record if one doesn't exist
                asset_history_model.create(asset_vals)

    def _update_asset_fixed_ok_to_false(self):
        for record in self:
            asset_history_model = self.env['fixed.asset.management.history']
            # Find all assets related to the product
            assets = asset_history_model.search([('asset_name', '=', record.product_variant_id.id)])
            for asset in assets:
                # Mark the asset as not a fixed asset (set fixed_ok to False)
                asset.write({'fixed_ok': False})
