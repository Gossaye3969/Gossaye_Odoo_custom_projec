from odoo import fields, models, api

import logging

_logger = logging.getLogger(__name__)


class HrEmployeeInherit(models.Model):
    _inherit = 'hr.employee'

    stock_location = fields.Many2one('stock.location', string="Fixed Asset Location")

    def _get_employee_product(self):
        employee_history_obj = self.env['hr.employee.lines'].sudo()
        employee_history_ids = []
        domain = [('location_id', '=', self.stock_location.id)]

        employee_product_line_ids = self.env['stock.quant'].sudo().search(domain,
                                                                          order='create_date desc')

        for line in employee_product_line_ids:
            employee_quant_history_id = employee_history_obj.create({
                'product_id': line.product_id.id,
                'onhand': line.quantity,
            })
            employee_history_ids.append(employee_quant_history_id.id)
        self.product_onhand_lines = employee_history_ids

    product_onhand_lines = fields.Many2many('hr.employee.lines', string='On Hand Lines',
                                            compute='_get_employee_product')


class EmployeeLines(models.Model):
    _name = 'hr.employee.lines'

    onhand_id = fields.Many2one('hr.employee', string="onhand", ondelete='cascade')
    product_id = fields.Many2one('product.product', string="Product")
    tag = fields.Char(related='product_id.new_reference', string='Asset Tag', tracking=True, store=True)
    onhand = fields.Float(string="Onhand Quantity", default=0.0)
