# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'
    _check_company_auto = True

    picking_type_id = fields.Many2one('stock.picking.type', string='Default Request Type')
    picking_types_id = fields.Many2one('stock.picking.type', string='Default Return Type')
    company_id = fields.Many2one('res.company', string="Company", tracking=True, required=True,
                                 default=lambda self: self.env.company)
    setting_id = fields.Many2one('asset.management.request.history')

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        company_id = self.env.company.id
        picking_type_id = self.env['ir.default'].sudo()._get('res.config.settings', 'picking_type_id',
                                                            company_id=company_id)
        picking_types_id = self.env['ir.default'].sudo()._get('res.config.settings', 'picking_types_id',
                                                             company_id=company_id)
        res.update({
            'picking_type_id': picking_type_id,
            'picking_types_id': picking_types_id,
        })
        return res

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        company_id = self.env.company.id
        if self.picking_type_id:
            self.env['ir.default'].sudo().set('res.config.settings', 'picking_type_id', self.picking_type_id.id,
                                              company_id=company_id)
        if self.picking_types_id:
            self.env['ir.default'].sudo().set('res.config.settings', 'picking_types_id', self.picking_types_id.id,
                                              company_id=company_id)
