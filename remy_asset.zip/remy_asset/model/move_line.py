from odoo import fields, models


class StockMoveLine(models.Model):
    _inherit = 'stock.move'

    description = fields.Text(string="Description")
    request_history_id = fields.Many2one('asset.management.request.history')
    inventory_ids = fields.Many2one('stock.move')


class StockTrackConfirmation(models.TransientModel):
    _inherit = 'stock.track.confirmation'
    _description = 'Stock Track Confirmation'

    inventory_id = fields.Many2one('stock.adjust', 'Inventory')


class StockTrackConfirmation(models.TransientModel):
    _inherit = 'stock.track.confirmation'


tracking_lines_ids = fields.One2many('stock.track.line', 'wizard_ids')
inventory_ids = fields.Many2one('stock.adjust', 'Inventory')


class StockTrackingLines(models.TransientModel):
    _inherit = 'stock.track.line'
    wizard_ids = fields.Many2one('stock.track.confirmation', readonly=True)
