from odoo import models, fields, api
from odoo.exceptions import ValidationError


class HRDepartment(models.Model):
    _inherit = 'hr.department'

    short_name = fields.Char(string='Short Name')

    @api.constrains('short_name')
    def _check_short_name_length(self):
        for record in self:
            if record.short_name and len(record.short_name) > 3:
                raise ValidationError("The Short Name must be 3 characters or fewer!")
