from odoo import api, fields, models


class ProductOnHandView(models.TransientModel):
    _name = 'product.on.hand.view'
    _description = 'Product On-Hand View'

    location_id = fields.Many2one('stock.location', string='Location', required=True)
    product_lines = fields.One2many('product.on.hand.line', 'view_id', string='Products')

    def action_show_products(self):
        products = self.env['product.product'].search([])
        product_lines = []
        for product in products:
            available_qty = product.with_context(location=self.location_id.id).qty_available
            if available_qty >= 1:  # Filter products with on-hand quantity >= 1
                product_lines.append((0, 0, {
                    'product_id': product.id,
                    'available_quantity': available_qty,
                }))
        # Sort product lines based on available quantity in ascending order
        sorted_product_lines = sorted(product_lines, key=lambda x: x[2]['available_quantity'])
        self.product_lines = sorted_product_lines

    def action_print_products(self):
        # Generate report or perform printing logic here
        # For demonstration, let's just print a message to console
        for product_line in self.product_lines:
            print("Product: %s, Available Quantity: %s" % (
                product_line.product_id.name, product_line.available_quantity))

    class ProductOnHandLine(models.TransientModel):
        _name = 'product.on.hand.line'
        _description = 'Product On-Hand Line'

        view_id = fields.Many2one('product.on.hand.view', string='View')
        product_id = fields.Many2one('product.product', string='Product', readonly=True)
        available_quantity = fields.Float(string='Available Quantity', readonly=True)
