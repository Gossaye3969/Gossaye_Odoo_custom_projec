from odoo import fields, models


class StockInventory(models.Model):
    _inherit = 'stock.quant'

    location_ids = fields.Many2many(
        'stock.location', 'stock_inventory_location_rel', 'inventory_id', 'location_id',
        string='Locations', domain="[('usage', 'in', ['internal', 'transit', 'fixed'])]"
    )
    accounting_date = fields.Datetime(string='Accounting Date', required=True, default=fields.Datetime.now)

