from odoo import models, fields, api,_


class PurchaseForecastAnalysis(models.Model):
    _name = 'general.report'
    _description = 'General Report Analysis'
    _auto = False

    product_name = fields.Many2one('product.product', string='Product', required=True, tracking=True)
    location_id = fields.Many2one('stock.location', string='Location')
    available_quantity = fields.Float('Available Quantity')

    def init(self):
        self._cr.execute("""
            CREATE OR REPLACE VIEW general_report AS (
                 SELECT
                        sq.id AS id,
                        sq.product_id AS product_name,
                        sq.location_id AS location_id,
                        sq.quantity AS available_quantity
                 FROM 
                        stock_quant sq
                 WHERE
                        sq.quantity >= 1
           )
        """)

