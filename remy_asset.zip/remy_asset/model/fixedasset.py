from odoo import api, fields, models, _
from datetime import timedelta
from odoo.exceptions import UserError


class AssetManagementHistory(models.Model):
    _name = 'fixed.asset.management.history'
    _inherit = 'product.template'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _check_company_auto = True
    _description = 'fixed asset '
    _rec_name = 'asset_name'

    category = fields.Many2one(
        'asset.management.history',
        string='Asset Category',  # Example domain for specific asset type
        tracking=True
    )
    fixed_ok = fields.Boolean(string="Fixed Asset", default=True)
    other_ok = fields.Boolean(string="Other Asset", default=False)
    used_ok = fields.Boolean(string="Used")
    asset_name = fields.Many2one('product.product', string="Asset Name", tracking=True
                                 # Only show products marked as
                                 # Fixed Asset
                                 )
    description = fields.Text(string="Description", tracking=True, store=True)
    serial_number = fields.Char('Serial Number', tracking=True, store=True)
    Responsible_person = fields.Many2one('hr.employee', string='Responsible Person', tracking=True)
    measure = fields.Many2one('uom.uom', string='Unit of Measure',
                              default=lambda self: self.env['uom.uom'].search([('name', '=', 'Pcs')], limit=1),
                              required=True, tracking=True, store=True)
    location = fields.Many2one('stock.location', string='Location', tracking=True)
    Quantity = fields.Float('Quantity', tracking=True)
    vendor = fields.Many2one('res.partner', string='Vendor', tracking=True, compute='_compute_vendor', store=True)
    initial_cost = fields.Float('Gross Value', tracking=True, store=True)
    salvage_value = fields.Float('Salvage Value', tracking=True, store=True)
    value_residual = fields.Float('Residual Value', tracking=True, compute='_compute_residual_value', store=True)
    purchase_date = fields.Datetime('Purchase Date', tracking=True, compute='_compute_purchase_date', store=True)
    invoice = fields.Many2one('account.move', string='Invoice', tracking=True)
    meeting_count = fields.Integer("meeting")
    on_hand_quantity = fields.Float(compute='_compute_on_hand_quantity', string="On Hand", readonly=True)
    purchase_order_count = fields.Float(compute='_compute_purchase_order_count', string="Number of Purchase Orders")
    image = fields.Binary(string='Image', attachment=True, store=True)
    prescription_line_id = fields.One2many('asset.depreciation.board', 'asset_id',
                                           string="prescription lines")
    prescription_id = fields.One2many('asset.depreciation.information', 'asset_id',
                                      string="prescription lines")
    state = fields.Selection(
        [('new', 'New'), ('used', 'Used'), ('disposed', 'Disposed')], default='new',
        string="Status", tracking=True)
    default_code = fields.Char(string='Internal Reference', tracking=True, store=True)
    asset_depreciation_information_ids = fields.One2many('asset.depreciation.information', 'asset_id',
                                                         string='Depreciation Information')
    new_reference = fields.Char(string='Asset Tag', tracking=True, store=True, compute='_compute_asset_tag')
    company_id = fields.Many2one('res.company', string="Company", tracking=True,
                                 default=lambda self: self.env.company, store=True)
    # Barcode Field
    barcode_value = fields.Char(string='Barcode', compute='_compute_barcode_value', store=True)
    brand = fields.Char('Brand', tracking=True, store=True)
    category_id = fields.Many2one('product.category', string='Product Category', tracking=True, store=True)

    # Compute method for the new_reference field
    @api.depends('company_id.short_name')
    def _compute_asset_tag(self):
        for record in self:
            if record.company_id and record.id:
                # Construct the Asset Tag using the GM/ + company shortname + asset id + /17
                record.new_reference = f"GM/{record.company_id.short_name}/{record.id}/17"
            else:
                record.new_reference = ''

    @api.onchange('fixed_ok')
    def _onchange_fixed_ok(self):
        if self.fixed_ok is False:
            # Update the corresponding product template record
            if self.asset_name:
                self.asset_name.fixed_asset = False  # Set fixed_asset field to False in related product template

    @api.model
    def create(self, vals):
        # Set the category of the related product.product to match category_id of the asset
        if 'category_id' in vals:
            # Check if asset_name is set; otherwise, raise an error
            if not vals.get('asset_name'):
                raise UserError(_("Asset Name must be defined before setting the Product Category."))

            # Fetch product.product record associated with the asset_name and set categ_id
            product = self.env['product.product'].browse(vals['asset_name'])
            if product:
                product.categ_id = vals['category_id']

        return super(AssetManagementHistory, self).create(vals)

    @api.depends('asset_name')
    def _compute_vendor(self):
        """Retrieve the latest vendor for the asset based on purchase orders."""
        for record in self:
            if record.asset_name:
                # Search for the latest purchase order related to the asset
                purchase_order = self.env['purchase.order'].search([
                    ('order_line.product_id', '=', record.asset_name.id),
                    ('state', 'in', ['purchase', 'done'])  # Only confirmed or done POs
                ], order="date_order desc", limit=1)

                # Set the vendor based on the latest purchase order
                record.vendor = purchase_order.partner_id if purchase_order else False

    @api.depends('asset_name')
    def _compute_purchase_date(self):
        """Retrieve the latest purchase date of the asset from the Purchase Orders."""
        for record in self:
            if record.asset_name:
                # Search for purchase orders related to this asset (product)
                purchase_orders = self.env['purchase.order.line'].search([
                    ('product_id', '=', record.asset_name.id),
                    ('order_id.state', 'in', ['purchase', 'done'])  # Only confirmed or done POs
                ], order="date_order desc", limit=1)

                if purchase_orders:
                    record.purchase_date = purchase_orders[0].order_id.date_order
                else:
                    record.purchase_date = False  # No purchase date if there are no POs

    def unlink(self):
        for record in self:
            if record.asset_name and self.env['stock.move'].search([('product_id', '=', record.asset_name.id)]):
                raise UserError(_("You cannot delete an asset that has associated stock moves."))
        return super(AssetManagementHistory, self).unlink()

    @api.onchange('asset_name')
    def _onchange_asset_name(self):
        """Retrieve default_code from product.product when asset_name is selected."""
        if self.asset_name and not self.default_code:
            self.default_code = self.asset_name.default_code  # Set initial default_code from selected product

    @api.onchange('new_reference')
    def _onchange_new_reference(self):
        """Automatically update the product's default_code when new_reference is set."""
        if self.asset_name and self.new_reference:
            self.asset_name.default_code = self.new_reference  # Update default_code in product.product only

    @api.model
    def create(self, vals):
        """Override create method to set purchase_ok and sale_ok for related product."""
        res = super(AssetManagementHistory, self).create(vals)
        if res.asset_name:
            res.asset_name.write({
                'purchase_ok': True,
                'sale_ok': False
            })
        return res

    def write(self, vals):
        """Override write method to update purchase_ok and sale_ok for related product on update."""
        res = super(AssetManagementHistory, self).write(vals)
        for record in self:
            if record.asset_name:
                record.asset_name.write({
                    'purchase_ok': True,
                    'sale_ok': False
                })
        return res

    @api.depends('asset_name', 'new_reference')  # Include new_reference
    def _compute_barcode_value(self):
        for record in self:
            if record.asset_name and record.new_reference:
                # Generate a barcode based on the asset name, default code, and new reference
                record.barcode_value = f"{record.asset_name.name}-{record.new_reference}"  # Customize as needed
            else:
                record.barcode_value = False  # Reset if any required fields are missing

    @api.depends('company_id', 'asset_name')
    def _compute_on_hand_quantity(self):
        for record in self:
            if not record.asset_name or not record.company_id:
                record.on_hand_quantity = 0.0
                continue

            # Retrieve all stock locations associated with the company
            locations = self.env['stock.location'].search(
                [('company_id', '=', record.company_id.id), ('usage', '=', 'fixed')])

            # Calculate the total quantity in all locations for the asset
            total_quantity = 0.0
            quants = self.env['stock.quant'].search([
                ('location_id', 'in', locations.ids),
                ('product_id', '=', record.asset_name.id)
            ])
            for quant in quants:
                total_quantity += quant.quantity

            record.on_hand_quantity = total_quantity

    @api.onchange('description')
    def _onchange_description(self):
        if self.asset_name:
            product_template = self.env['product.template'].search([('id', '=', self.asset_name.id)], limit=1)
            if product_template:
                product_template.description = self.description

    @api.onchange('asset_name')
    def onchange_asset_name(self):
        """
        Automatically select the Unit of Measure and description based on the requested item.
        """
        if self.asset_name:
            # Set UoM to the default UoM of the requested item
            self.measure = self.asset_name.uom_id.id
            # Set description to the description of the requested item
            self.description = self.asset_name.description
            self.image = self.asset_name.image_1920

    def generate_depreciation_board_entries(self):
        """Generate depreciation entries in the board"""
        for asset in self:
            asset.asset_depreciation_information_ids.generate_depreciation_entries()

    def write(self, vals):
        if 'state' in vals and vals['state'] == 'new' and self.state == 'used':
            raise UserError(_('Cannot set a Used record back to New.'))
        return super(AssetManagementHistory, self).write(vals)

    def action_new(self):
        self.state = 'new'

    def action_used(self):
        self.state = 'used'

    def action_disposed(self):
        self.state = 'disposed'

    @api.depends('initial_cost', 'salvage_value')
    def _compute_residual_value(self):
        for asset in self:
            asset.value_residual = asset.initial_cost - asset.salvage_value


class AssetDepreciationBoard(models.Model):
    _name = 'asset.depreciation.board'
    _description = 'Depreciation Board'

    asset_id = fields.Many2one('fixed.asset.management.history', string='Asset')
    depreciation_date = fields.Date(string=' Depreciation Date')
    cumulative_depreciation = fields.Float(string='Cumulative Depreciation')
    residual_value = fields.Float(string='Residual Value')
    depreciations = fields.Integer(string='Depreciations', compute='_compute_depreciations')

    @api.depends('asset_id', 'residual_value', 'asset_id.asset_depreciation_information_ids')
    def _compute_depreciations(self):
        """Compute depreciation amount based on residual value and number of depreciations"""
        for record in self:
            if record.asset_id:
                # Get the total number of depreciations from related asset depreciation information
                total_depreciations = sum(
                    info.number_of_depreciations for info in record.asset_id.asset_depreciation_information_ids)
                # Compute depreciation amount if total_depreciations is not zero
                if total_depreciations:
                    record.depreciations = record.residual_value / total_depreciations
                else:
                    record.depreciations = 0
            else:
                record.depreciations = 0


class AssetDepreciationInformation(models.Model):
    _name = 'asset.depreciation.information'
    _description = 'Depreciation Information'

    asset_id = fields.Many2one('fixed.asset.management.history', string='Asset')
    depreciation_method = fields.Selection([('linear', 'Linear'), ('declining_balance', 'Declining Balance')],
                                           string='Depreciation Method')
    prorata_temporis = fields.Boolean(string='Prorata Temporis')
    number_of_depreciations = fields.Integer(string='Number of Depreciations')
    number_of_months_in_period = fields.Integer(string='Number of Months in Period', default=12)
    fixed_asset_account_id = fields.Many2one('account.account', string='Fixed Asset Account')
    depreciation_account_id = fields.Many2one('account.account', string='Depreciation Account')
    expense_account_id = fields.Many2one('account.account', string='Expense Account')
    depreciation_board_id = fields.Many2one('asset.depreciation.board', string='Depreciation Board')

    @api.depends('asset_id', 'number_of_depreciations', 'asset_id.value_residual')
    def _compute_depreciations(self):
        """Compute depreciations based on residual value and number of depreciations"""
        for info in self:
            if info.number_of_depreciations:
                info.depreciations = info.asset_id.value_residual / info.number_of_depreciations
            else:
                info.depreciations = 0.0

    @api.model_create_multi
    def create(self, vals_list):
        # Call super method to create records
        records = super(AssetDepreciationInformation, self).create(vals_list)
        # Generate depreciation entries
        records.generate_depreciation_entries()
        return records

    def generate_depreciation_entries(self):
        """Generate depreciation entries based on the information provided"""
        depreciation_board_values = []
        for info in self:
            if info.depreciation_method == 'linear':
                depreciation_amount = (
                                              info.asset_id.initial_cost - info.asset_id.salvage_value) / info.number_of_depreciations
            elif info.depreciation_method == 'declining_balance':
                # Implement declining balance depreciation calculation here
                pass
            else:
                continue  # Handle other depreciation methods if needed

            # Calculate depreciation date and amount for each period
            depreciation_date = info.asset_id.purchase_date
            for i in range(info.number_of_depreciations):
                depreciation_date += timedelta(days=30 * info.number_of_months_in_period)
                depreciation_board_values.append({
                    'asset_id': info.asset_id.id,
                    'depreciation_date': depreciation_date,
                    'cumulative_depreciation': depreciation_amount * (i + 1),
                    'residual_value': info.asset_id.initial_cost - depreciation_amount * (i + 1),
                })
        # Create depreciation board records
        self.env['asset.depreciation.board'].create(depreciation_board_values)
