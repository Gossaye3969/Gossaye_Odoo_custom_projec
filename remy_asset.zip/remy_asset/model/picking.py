from odoo import api, fields, models, _
from odoo.exceptions import UserError


class StockPicking(models.Model):
    _inherit = 'stock.picking'
    # Other fields remain unchanged

    request_id = fields.Many2one('asset.management.request.history', string='Request ')
    # New field for employee
    employee_id = fields.Many2one('hr.employee', string='Location manager', store=True)
    resp_id = fields.Many2one('hr.employee', string='Employee Name', store=True)
    department_id = fields.Many2one('hr.department', string='Department', store=True)
    handover_date = fields.Date(string='Handover Date', store=True, readonly=1)

    @api.model
    def action_handover(self):
        # Implement action logic here
        return True

    @api.onchange('location_id')
    def _onchange_location_id(self):
        if self.location_id:
            # Search for the location in stock.location where name matches the location_id's name
            location = self.env['stock.location'].search([('name', '=', self.location_id.name)], limit=1)
            if location and location.responsible:
                # Set the employee_id field to the responsible employee in the matching location
                self.employee_id = location.responsible
            else:
                # Clear the employee_id field if no matching responsible employee is found
                self.employee_id = False
