from odoo import fields, models,api


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    picking_types_id = fields.Many2one('stock.picking.type', string='Operation Type')