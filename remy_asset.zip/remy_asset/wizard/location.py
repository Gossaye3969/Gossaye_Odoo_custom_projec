from odoo import api, fields, models, _
from datetime import date


class AppointmentReportWizards(models.TransientModel):
    _name = "location.wizard"
    _description = "Print Asset Wizard"
    _order = "product_id"

    employee_id = fields.Many2one('hr.employee', string="Employee")

    employee_image = fields.Image(related='employee_id.image_1920', readonly=True
    )
    department_id = fields.Many2one('hr.department', related='employee_id.department_id', string="Department",
                                    tracking=True, required=True)

    location_id = fields.Many2one('stock.location', string="Location", related='employee_id.stock_location'
                                  , readonly=True)
    product_id = fields.Many2one('product.product', string="Asset Name")
    uom_id = fields.Many2one('uom.uom', 'Unit Of Measure')
    company_id = fields.Many2one('res.company', string='Company', required=True, readonly=True,
                                 default=lambda self: self.env.company)
    product_quant_ids = fields.One2many('location.wizard.product.quant', 'wizard_id', string='Product Quantities')
    date = fields.Date(string="As Of", default=fields.Date.context_today, readonly=True)  # New field with current date

    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        if self.employee_id:
            self.location_id = self.employee_id.stock_location
        else:
            self.location_id = False
        # Clear the One2many field when changing the employee
        self.product_quant_ids = [(5, 0, 0)]

    @api.onchange('location_id')
    def _onchange_location_id(self):
        if self.location_id:
            quants = self.env['stock.quant'].search([
                ('location_id', '=', self.location_id.id),
                ('quantity', '>=', 1)
            ])
            product_quants = []
            for index, quant in enumerate(quants, start=1):
                product_quants.append((0, 0, {
                    'sequence': index,
                    'product_id': quant.product_id.id,
                    'quantity': quant.quantity,
                    'uom_id': quant.product_id.uom_id.id,  # Retrieve UOM for the product
                }))
            self.product_quant_ids = product_quants
        else:
            self.product_quant_ids = [(5, 0, 0)]  # Clear the One2many field

    def print_report(self):
        return self.env.ref('remy_asset.report_return_employee_location_card').report_action(self)


class LocationWizardProductQuant(models.TransientModel):
    _name = "location.wizard.product.quant"
    _description = "Product Quantities in Wizard"

    wizard_id = fields.Many2one('location.wizard', string='Wizard', required=True, ondelete='cascade')
    sequence = fields.Integer(string='No', default=1)
    product_id = fields.Many2one('product.product', string='Asset ', required=True)
    quantity = fields.Float(string='Quantity On Hand', required=True)
    uom_id = fields.Many2one('uom.uom', 'Unit Of Measure')
