from odoo import api, fields, models, _


class AppointmentReportWizards(models.TransientModel):
    _name = "asset.card.wizard"
    _description = "print Asset Wizard"
    _order = "product_id"

    employee_id = fields.Many2one('hr.employee', string="Employee")
    Location = fields.Many2one('stock.location', string="Location")
    location_id = fields.Many2one('stock.location', string="Location")
    product_id = fields.Many2one('product.product', string="Product")
    stock_location = fields.Many2one('stock.location', "Location", company_dependent=True,
                                     related='employee_id.stock_location',
                                     check_company=True, readonly=False)
    product_template_id = fields.Many2one('product.product', string='Asset NAme',
                                          domain="[('active', '=', True)]")
    product_moves = fields.One2many('stock.move.line', compute='_stock_moves')
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.company)

    @api.onchange('product_id', 'stock_location')
    def _stock_moves(self):
        for wizard in self:
            domain = [('state', '=', 'done')]
            if wizard.product_id and wizard.stock_location:
                # If both product and location are selected, filter by both
                domain += ['&', ('product_id', '=', wizard.product_id.id),
                           '|', ('location_id', '=', wizard.stock_location.id),
                           ('location_dest_id', '=', wizard.stock_location.id)]
            elif wizard.stock_location:
                # If only location is selected, filter by it for both source and destination locations
                domain += ['|', ('location_id', '=', wizard.stock_location.id),
                           ('location_dest_id', '=', wizard.stock_location.id)]
            elif wizard.product_id:
                # If only product is selected, filter by product
                domain += [('product_id', '=', wizard.product_id.id)]

            wizard.product_moves = self.env['stock.move.line'].search(domain)

    def print_report(self):
        return self.env.ref('remy_asset.report_asset_card_wizard').report_action(self)
