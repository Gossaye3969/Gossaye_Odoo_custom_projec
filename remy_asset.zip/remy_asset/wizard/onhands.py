from odoo import api, fields, models


class ProductOnHandView(models.TransientModel):
    _name = 'product.on.hand.views'
    _description = 'Product On-Hand View'
    _rec_name = 'location_id'

    employee_id = fields.Many2one('hr.employee', string="Employee")
    location_id = fields.Many2one('stock.location', string='Location', required=True)
    product_lines = fields.One2many('product.on.hand.lines', 'view_id', string='Products')

    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        if self.employee_id:
            # Assuming there is a field 'location_id' in hr.employee model that links to stock.location
            self.location_id = self.employee_id.stock_location
        else:
            self.location_id = False

    @api.onchange('location_id')
    def onchange_location_id(self):
        if self.location_id:
            self.product_lines = False  # Clear existing product lines
            self.action_show_products()

    def action_show_products(self):
        products = self.env['product.product'].search([])
        product_lines = []
        for product in products:
            available_qty = product.with_context(location=self.location_id.id).qty_available
            if available_qty >= 1:  # Filter products with on-hand quantity >= 1
                product_lines.append((0, 0, {
                    'product_id': product.id,
                    'available_quantity': available_qty,
                }))
        # Sort product lines based on available quantity in ascending order
        sorted_product_lines = sorted(product_lines, key=lambda x: x[2]['available_quantity'])
        self.product_lines = sorted_product_lines

    def print_report(self):
        return self.env.ref('remy_asset.report_asset_card_wizards').report_action(self)

    class ProductOnHandLine(models.TransientModel):
        _name = 'product.on.hand.lines'
        _description = 'Product On-Hand Line'

        view_id = fields.Many2one('product.on.hand.views', string='View')
        product_id = fields.Many2one('product.product', string='Product', readonly=True)
        available_quantity = fields.Float(string='Available Quantity', readonly=True)
