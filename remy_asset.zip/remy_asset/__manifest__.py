# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'Fixed Asset Management',
    'version': '1.1',
    'summary': 'Remy Asset Management',
    'sequence': 1,
    'description': "asset management"

    ,
    'category': 'Fixed Asset',
    'website': 'https://www.remytradingplc.com',
    'depends': [
        'sale','mail','base', 'stock','product','hr','web'
    ],
    'assets': {
      'web.assets_backend': [
        'remy_asset/static/src/css/custom_styles.css',
      ],
   },
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'data/data.xml',
        'wizard/AssetCard.xml',
        'wizard/locatio_report.xml',
        'wizard/location.xml',
        'wizard/wizard.xml',
        'wizard/onhandrep.xml',
        'view/asset.xml',
        'view/assetform.xml',
        'view/stock_location.xml',
        'view/fixedasset.xml',
        'view/general.xml',
        'view/viewProduct.xml',
        'view/company.xml',
        'view/department.xml',
        'view/product.xml',
        'view/picking.xml',
        'view/asset_card_report.xml',
        'view/assetreports.xml',
        'view/assetreturn.xml',
        'view/stock.xml',
        'view/onhands_views.xml',
       'view/res_config_settings_views.xml',
        'view/hand.xml',
        'view/move_line.xml',
        'view/employee.xml',
        'view/fixed_location.xml',
        'report/assetrequset.xml',
        'report/inventory.xml',
        'report/assetreturn.xml',
        'report/requestpicking.xml',
        'report/return_picking.xml',
        'report/report.xml',
        'report/assetcard.xml',
        'report/product_barcode.xml',
        'report/asset_card_report.xml',


    ],
    'qweb': [

    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}